package Model;


public class BeerModel {

}
